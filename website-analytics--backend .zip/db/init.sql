-- Run this to initialize the database schema.

CREATE TABLE IF NOT EXISTS apps (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  owner_email TEXT NOT NULL,
  api_key_hash TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now(),
  revoked_at TIMESTAMPTZ,
  expires_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS events (
  id BIGSERIAL PRIMARY KEY,
  app_id INTEGER REFERENCES apps(id) ON DELETE CASCADE,
  event_name TEXT NOT NULL,
  url TEXT,
  referrer TEXT,
  device TEXT,
  ip_address TEXT,
  timestamp TIMESTAMPTZ DEFAULT now(),
  metadata JSONB,
  user_id TEXT,
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_events_app_event_time ON events (app_id, event_name, timestamp);
CREATE INDEX IF NOT EXISTS idx_events_user_id ON events (user_id);
