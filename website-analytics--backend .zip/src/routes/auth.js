const express = require('express');
const router = express.Router();
const db = require('../db');
const { v4: uuidv4 } = require('uuid');
const bcrypt = require('bcrypt');

const saltRounds = 10;

/**
 * POST /api/auth/register
 * Body: { name, owner_email }
 * Returns: { appId, apiKey } (apiKey shown once)
 */
router.post('/register', async (req, res) => {
  const { name, owner_email } = req.body;
  if (!name || !owner_email) return res.status(400).json({error: 'name and owner_email required'});

  const apiKeyPlain = uuidv4() + '-' + Math.random().toString(36).slice(2,8);
  const apiKeyHash = await bcrypt.hash(apiKeyPlain, saltRounds);

  const q = `INSERT INTO apps (name, owner_email, api_key_hash, created_at)
             VALUES ($1, $2, $3, now()) RETURNING id`;
  try {
    const r = await db.query(q, [name, owner_email, apiKeyHash]);
    return res.status(201).json({ appId: r.rows[0].id, apiKey: apiKeyPlain });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'internal_error' });
  }
});

/**
 * POST /api/auth/revoke
 * Body: { appId }
 */
router.post('/revoke', async (req, res) => {
  const { appId } = req.body;
  if (!appId) return res.status(400).json({ error: 'appId required' });
  try {
    await db.query('UPDATE apps SET revoked_at = now() WHERE id = $1', [appId]);
    return res.json({ ok: true });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'internal_error' });
  }
});

module.exports = router;
