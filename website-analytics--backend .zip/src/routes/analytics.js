const express = require('express');
const router = express.Router();
const db = require('../db');
const auth = require('../middleware/auth');

/**
 * POST /api/analytics/collect
 * Header: x-api-key
 * Body: { event, url, referrer, device, ipAddress, timestamp, metadata }
 */
router.post('/collect', auth, async (req, res) => {
  const { event, url, referrer, device, ipAddress, timestamp, metadata, userId } = req.body;
  if (!event) return res.status(400).json({ error: 'event required' });

  const q = `INSERT INTO events (app_id, event_name, url, referrer, device, ip_address, timestamp, metadata, user_id, created_at)
             VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9, now()) RETURNING id`;
  try {
    const r = await db.query(q, [req.app_id, event, url || null, referrer || null, device || null, ipAddress || null, timestamp ? new Date(timestamp) : new Date(), metadata || null, userId || null]);
    return res.status(202).json({ accepted: true, id: r.rows[0].id });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'internal_error' });
  }
});

/**
 * GET /api/analytics/event-summary
 * Query: event, startDate, endDate, app_id (optional)
 */
router.get('/event-summary', async (req, res) => {
  const { event, startDate, endDate, app_id } = req.query;
  if (!event) return res.status(400).json({ error: 'event query param required' });

  let q = `SELECT COUNT(*) AS count,
                  COUNT(DISTINCT user_id) AS unique_users,
                  SUM(CASE WHEN device='mobile' THEN 1 ELSE 0 END) AS mobile,
                  SUM(CASE WHEN device='desktop' THEN 1 ELSE 0 END) AS desktop
           FROM events
           WHERE event_name = $1`;
  const params = [event];
  if (startDate) {
    params.push(startDate);
    q += ` AND timestamp >= $${params.length}`;
  }
  if (endDate) {
    params.push(endDate);
    q += ` AND timestamp <= $${params.length}`;
  }
  if (app_id) {
    params.push(app_id);
    q += ` AND app_id = $${params.length}`;
  }

  try {
    const r = await db.query(q, params);
    const row = r.rows[0];
    return res.json({
      event,
      count: parseInt(row.count, 10),
      uniqueUsers: parseInt(row.unique_users || 0, 10),
      deviceData: {
        mobile: parseInt(row.mobile || 0, 10),
        desktop: parseInt(row.desktop || 0, 10),
      }
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'internal_error' });
  }
});

/**
 * GET /api/analytics/user-stats?userId=...
 */
router.get('/user-stats', async (req, res) => {
  const { userId } = req.query;
  if (!userId) return res.status(400).json({ error: 'userId required' });

  try {
    const total = await db.query('SELECT COUNT(*) AS total FROM events WHERE user_id = $1', [userId]);
    const device = await db.query(`SELECT metadata->>'browser' AS browser, metadata->>'os' AS os, ip_address
                                   FROM events WHERE user_id = $1 ORDER BY timestamp DESC LIMIT 1`, [userId]);
    const devRow = device.rows[0] || {};
    return res.json({
      userId,
      totalEvents: parseInt(total.rows[0].total, 10),
      deviceDetails: {
        browser: devRow.browser || null,
        os: devRow.os || null,
      },
      ipAddress: devRow.ip_address || null
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'internal_error' });
  }
});

module.exports = router;
