const db = require('../db');
const bcrypt = require('bcrypt');

// Middleware to authenticate using x-api-key header
module.exports = async function(req, res, next) {
  const key = req.headers['x-api-key'];
  if (!key) return res.status(401).json({ error: 'missing_api_key' });

  try {
    const r = await db.query('SELECT id, api_key_hash, revoked_at, expires_at FROM apps');
    const apps = r.rows;
    for (const app of apps) {
      if (app.revoked_at) continue;
      if (app.expires_at && new Date(app.expires_at) < new Date()) continue;
      const match = await bcrypt.compare(key, app.api_key_hash);
      if (match) {
        req.app_id = app.id;
        return next();
      }
    }
    return res.status(401).json({ error: 'invalid_api_key' });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'internal_error' });
  }
};
