const request = require('supertest');
const express = require('express');
const analytics = require('../src/routes/analytics');
const auth = require('../src/middleware/auth');

describe('basic sanity', () => {
  test('server route mount', () => {
    const app = express();
    app.use(express.json());
    app.use('/api/analytics', analytics);
    expect(true).toBe(true);
  });
});
